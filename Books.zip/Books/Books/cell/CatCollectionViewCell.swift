//
//  CatCollectionViewCell.swift
//  Books
//
//  Created by Muhammad Usman on 28/03/1441 AH.
//  Copyright © 1441 Macbook. All rights reserved.
//

import UIKit

class CatCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var catImage: UIImageView!
    @IBOutlet weak var catlabel: UILabel!
    
}
